from flask import Flask, request, render_template, session, redirect, url_for
import numpy as np
import pickle

# Load the model
model = pickle.load(open('RandomForest.pkl', 'rb'))

# Create a Flask app
app = Flask(__name__)

@app.route('/')
def login():
      return render_template("index.html", result=None)

# @app.route('/', methods=['GET', 'POST'])
# def login():
#     if request.method == 'POST':
#         # Get form data
#         username = request.form['username']
#         password = request.form['password']
#
#         # Validate credentials
#         if username == 'admin' and password == 'admin':
#             # Successful login, set session variable
#             # session['logged_in'] = True
#             return render_template('index.html')
#         else:
#             return render_template('login.html', error='Invalid username or password')
#     else:
#         return render_template('login.html')

@app.route("/predict", methods=['POST'])
def predict():
    try:
        N = float(request.form['Nitrogen'])
        P = float(request.form['Phosporus'])
        K = float(request.form['Potassium'])
        temperature = float(request.form['Temperature'])
        humidity = float(request.form['Humidity'])
        ph = float(request.form['Ph'])
        rainfall = float(request.form['Rainfall'])

        data = np.array([[N, P, K, temperature, humidity, ph, rainfall]])
        my_prediction = model.predict(data)

        if my_prediction:
            result = my_prediction[0]
        else:
            result = "Sorry, we could not determine the best crop to be cultivated with the provided data."
    except Exception as e:
        result = f"An error occurred: {e}"

    return render_template('index.html', result=result)


# Python main
if __name__ == "__main__":
    app.run(debug=True)
