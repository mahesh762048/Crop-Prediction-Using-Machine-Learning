from flask import Flask, request, render_template, session, redirect, url_for
import numpy as np
import pickle

# Load the model
model = pickle.load(open('D:\Crop Recommender\model\cropmodel2.pkl', 'rb'))

# Create a Flask app
app = Flask(__name__)

@app.route('/index.html')
def index():
      return render_template("index.html", result=None)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/contact.html')
def contact():
    return render_template('contact.html')

@app.route('/simple.html')
def login():
    return render_template('simple.html')

@app.route('/about.html')
def about():
    return render_template('about.html')

@app.route('/info.html')
def info():
    return render_template('info.html')

@app.route('/onion.html')
def onion():
    return render_template('onion.html')

@app.route('/Maize.html')
def Maize():
    return render_template('Maize.html')

@app.route('/chickpi.html')
def chickpi():
    return render_template('chickpi.html')

@app.route('/kidneybeans.html')
def kidneybeans():
    return render_template('kidneybeans.html')

@app.route('/pigeonpeas.html')
def pigeonpeas():
    return render_template('pigeonpeas.html')

@app.route('/mothbeans.html')
def mothbeans():
    return render_template('mothbeans.html')

@app.route('/mungbeans.html')
def mungbeans():
    return render_template('mungbeans.html')

@app.route("/predict", methods=['POST'])
def predict():
    try:
        N = float(request.form['Nitrogen'])
        P = float(request.form['Phosporus'])
        K = float(request.form['Potassium'])
        temperature = float(request.form['Temperature'])
        humidity = float(request.form['Humidity'])
        ph = float(request.form['Ph'])
        rainfall = float(request.form['Rainfall'])

        data = np.array([[N, P, K, temperature, humidity, ph, rainfall]])
        my_prediction = model.predict(data)
        
        original_labels = ['rice', 'maize', 'chickpea', 'kidneybeans', 'pigeonpeas',
       'mothbeans', 'mungbean', 'blackgram', 'lentil', 'pomegranate',
       'banana', 'mango', 'grapes', 'watermelon', 'muskmelon', 'apple',
       'orange', 'papaya', 'coconut', 'cotton', 'jute', 'coffee']
        labels_map_new = {i+1:original_labels[i] for i in range(len(original_labels))}
         
        if my_prediction[0] in labels_map_new:
            crop = labels_map_new[my_prediction[0]]
            result = crop

        # if my_prediction:
        #     result = my_prediction[0]
        else:
            result = "Sorry, we could not determine the best crop to be cultivated with the provided data."
    except Exception as e:
        result = f"An error occurred: {e}"

    return render_template('index.html', result=result)


# Python main
if __name__ == "__main__":
    app.run(debug=True)
